create view s4_5(cursus, aantal) as
SELECT ui.cursus,
       count(ui.cursus) AS aantal
FROM uitvoeringen ui
         JOIN cursussen c ON c.code::text = ui.cursus::text
GROUP BY ui.cursus
HAVING count(*) >= 0;

alter table s4_5
    owner to postgres;


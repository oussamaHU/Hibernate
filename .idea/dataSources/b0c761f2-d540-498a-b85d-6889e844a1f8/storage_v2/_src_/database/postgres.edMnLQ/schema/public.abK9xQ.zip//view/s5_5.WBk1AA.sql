create view s5_5(resultaat) as
SELECT 'S5.5 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s5_5
    owner to postgres;


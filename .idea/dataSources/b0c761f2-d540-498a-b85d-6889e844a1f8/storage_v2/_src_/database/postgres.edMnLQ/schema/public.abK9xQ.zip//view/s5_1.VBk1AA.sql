create view s5_1(resultaat) as
SELECT 'S5.1 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s5_1
    owner to postgres;


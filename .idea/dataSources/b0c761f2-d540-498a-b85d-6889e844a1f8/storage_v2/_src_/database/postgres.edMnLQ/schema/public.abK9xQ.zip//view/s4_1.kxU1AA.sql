create view s4_1(resultaat) as
SELECT 'S4.1 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s4_1
    owner to postgres;


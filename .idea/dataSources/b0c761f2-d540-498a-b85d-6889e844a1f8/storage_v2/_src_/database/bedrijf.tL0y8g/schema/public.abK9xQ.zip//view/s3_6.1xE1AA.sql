create view s3_6(naam, toelage) as
SELECT m.naam,
       s.toelage
FROM medewerkers m,
     schalen s
WHERE m.maandsal >= s.ondergrens
  AND m.maandsal <= s.bovengrens;

alter table s3_6
    owner to postgres;


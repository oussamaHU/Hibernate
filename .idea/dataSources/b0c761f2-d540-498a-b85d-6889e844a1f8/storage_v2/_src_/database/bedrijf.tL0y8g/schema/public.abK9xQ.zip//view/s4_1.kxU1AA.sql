create view s4_1(mnr, functie, medewerker) as
SELECT m.mnr,
       m.functie,
       m.gbdatum AS medewerker
FROM medewerkers m
WHERE m.functie::text = 'TRAINER'::text
   OR m.functie::text = 'VERKOPER'::text
GROUP BY m.mnr, m.functie, m.gbdatum
HAVING m.gbdatum < '1980-01-01'::date;

alter table s4_1
    owner to postgres;


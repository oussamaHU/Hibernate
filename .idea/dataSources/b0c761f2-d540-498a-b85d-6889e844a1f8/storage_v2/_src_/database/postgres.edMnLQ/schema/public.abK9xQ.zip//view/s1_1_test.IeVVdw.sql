create view s1_1_test(column_name) as
SELECT columns.column_name
FROM information_schema.columns
WHERE columns.table_schema::text = 'public'::text
  AND columns.table_name::text = 'medewerkers'::text
  AND columns.column_name::text = 'geslacht'::text;

alter table s1_1_test
    owner to postgres;


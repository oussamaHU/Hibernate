create view s5_3_test(mnr) as
SELECT answer.mnr
FROM (VALUES (7902::numeric(4, 0)), (7934), (7369), (7654), (7521), (7844), (7900)) answer(mnr);

alter table s5_3_test
    owner to postgres;


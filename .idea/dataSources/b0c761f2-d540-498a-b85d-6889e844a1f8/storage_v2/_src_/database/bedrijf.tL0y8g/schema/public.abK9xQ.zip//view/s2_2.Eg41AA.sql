create view s2_2(resultaat) as
SELECT 'S2.2 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s2_2
    owner to postgres;


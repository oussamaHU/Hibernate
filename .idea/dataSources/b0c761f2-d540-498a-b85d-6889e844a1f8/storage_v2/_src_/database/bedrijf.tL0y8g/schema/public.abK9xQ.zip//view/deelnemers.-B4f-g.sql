create view deelnemers(cursist, cursus, begindatum, docent, locatie) as
SELECT i.cursist,
       i.cursus,
       i.begindatum,
       u.docent,
       u.locatie
FROM inschrijvingen i
         JOIN uitvoeringen u ON i.cursus::text = u.cursus::text AND i.begindatum = u.begindatum;

alter table deelnemers
    owner to postgres;


create view s3_3_test(afdeling, hoofd) as
SELECT answer.afdeling,
       answer.hoofd
FROM (VALUES ('HOOFDKANTOOR'::character varying(20), 'CLERCKX'::character varying(12)),
             ('OPLEIDINGEN'::character varying, 'JANSEN'::character varying),
             ('VERKOOP'::character varying, 'BLAAK'::character varying),
             ('PERSONEELSZAKEN'::character varying, 'DE KONING'::character varying)) answer(afdeling, hoofd);

alter table s3_3_test
    owner to postgres;


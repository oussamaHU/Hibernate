create view s4_7(resultaat) as
SELECT 'S4.7 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s4_7
    owner to postgres;


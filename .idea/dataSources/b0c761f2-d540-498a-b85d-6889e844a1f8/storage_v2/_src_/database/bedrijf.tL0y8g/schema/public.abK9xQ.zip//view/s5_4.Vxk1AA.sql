create view s5_4(naam) as
SELECT m.naam
FROM medewerkers m
WHERE (m.mnr IN (SELECT m2.chef
                 FROM medewerkers m2
                 WHERE m.mnr = m2.chef));

alter table s5_4
    owner to postgres;


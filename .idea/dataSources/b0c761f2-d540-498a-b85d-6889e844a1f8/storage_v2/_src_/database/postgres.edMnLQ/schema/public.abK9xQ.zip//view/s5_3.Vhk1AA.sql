create view s5_3(resultaat) as
SELECT 'S5.3 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s5_3
    owner to postgres;


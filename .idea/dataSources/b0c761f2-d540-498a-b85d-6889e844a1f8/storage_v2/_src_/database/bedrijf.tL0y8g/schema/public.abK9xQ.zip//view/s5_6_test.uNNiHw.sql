create view s5_6_test(cursus, begindatum, aantal_inschrijvingen) as
SELECT answer.cursus,
       answer.begindatum,
       answer.aantal_inschrijvingen
FROM (VALUES ('S02'::character varying(12), '2019-04-12'::date, 4::bigint),
             ('OAG'::character varying, '2019-08-10'::date, 3),
             ('S02'::character varying, '2019-10-04'::date, 3),
             ('S02'::character varying, '2019-12-13'::date, 2),
             ('JAV'::character varying, '2019-12-13'::date, 5),
             ('JAV'::character varying, '2020-02-01'::date, 3),
             ('XML'::character varying, '2020-02-03'::date, 2),
             ('PLS'::character varying, '2020-09-11'::date, 3),
             ('XML'::character varying, '2020-09-18'::date, 0),
             ('OAG'::character varying, '2020-09-27'::date, 1),
             ('ERM'::character varying, '2021-01-15'::date, 0),
             ('PRO'::character varying, '2021-02-19'::date, 0),
             ('RSO'::character varying, '2021-02-24'::date, 0)) answer(cursus, begindatum, aantal_inschrijvingen);

alter table s5_6_test
    owner to postgres;


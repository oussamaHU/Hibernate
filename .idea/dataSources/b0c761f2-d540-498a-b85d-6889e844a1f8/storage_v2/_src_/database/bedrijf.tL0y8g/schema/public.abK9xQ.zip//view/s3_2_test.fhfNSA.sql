create view s3_2_test(cursist, docent) as
SELECT answer.cursist,
       answer.docent
FROM (VALUES ('ALDERS'::character varying(12), 'SPIJKER'::character varying(12)),
             ('BLAAK'::character varying, 'SMIT'::character varying),
             ('BLAAK'::character varying, 'SPIJKER'::character varying),
             ('SCHOTTEN'::character varying, 'SMIT'::character varying),
             ('DE KONING'::character varying, 'SMIT'::character varying),
             ('ADAMS'::character varying, 'SPIJKER'::character varying),
             ('SPIJKER'::character varying, 'SMIT'::character varying),
             ('SPIJKER'::character varying, 'SMIT'::character varying),
             ('MOLENAAR'::character varying, 'SPIJKER'::character varying)) answer(cursist, docent);

alter table s3_2_test
    owner to postgres;


create view s5_5_test(cursus, begindatum) as
SELECT answer.cursus,
       answer.begindatum
FROM (VALUES ('XML'::character varying(12), '2020-02-03'::date),
             ('JAV'::character varying, '2020-02-01'::date),
             ('PLS'::character varying, '2020-09-11'::date),
             ('XML'::character varying, '2020-09-18'::date)) answer(cursus, begindatum);

alter table s5_5_test
    owner to postgres;


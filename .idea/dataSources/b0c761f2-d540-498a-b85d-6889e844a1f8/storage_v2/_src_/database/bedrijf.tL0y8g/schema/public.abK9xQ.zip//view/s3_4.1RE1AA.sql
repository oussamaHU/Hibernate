create view s3_4(medewerker, naam, locatie) as
SELECT m.naam AS medewerker,
       a.naam,
       a.locatie
FROM medewerkers m
         JOIN afdelingen a ON a.anr = m.afd;

alter table s3_4
    owner to postgres;


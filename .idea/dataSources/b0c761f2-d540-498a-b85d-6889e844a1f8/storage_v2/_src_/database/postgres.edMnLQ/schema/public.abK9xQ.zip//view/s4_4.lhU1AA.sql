create view s4_4(resultaat) as
SELECT 'S4.4 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s4_4
    owner to postgres;


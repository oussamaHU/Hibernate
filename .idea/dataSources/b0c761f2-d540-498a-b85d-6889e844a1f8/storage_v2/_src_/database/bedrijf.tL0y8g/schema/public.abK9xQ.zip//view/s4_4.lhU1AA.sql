create view s4_4(mnr, cursus) as
SELECT m.mnr,
       i.cursus
FROM medewerkers m
         JOIN inschrijvingen i ON m.mnr = i.cursist
GROUP BY m.mnr, i.cursist, i.cursus
HAVING count(*) > 1;

alter table s4_4
    owner to postgres;


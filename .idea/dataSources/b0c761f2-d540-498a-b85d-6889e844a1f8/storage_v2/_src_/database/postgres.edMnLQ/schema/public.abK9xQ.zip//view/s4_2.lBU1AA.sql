create view s4_2(resultaat) as
SELECT 'S4.2 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s4_2
    owner to postgres;


create view s4_7(aantal_medewerkers, commissie_medewerkers, commissie_verkopers) as
SELECT count(medewerkers.mnr)                    AS aantal_medewerkers,
       sum(medewerkers.comm) / count(*)::numeric AS commissie_medewerkers,
       avg(medewerkers.comm)                     AS commissie_verkopers
FROM medewerkers;

alter table s4_7
    owner to postgres;


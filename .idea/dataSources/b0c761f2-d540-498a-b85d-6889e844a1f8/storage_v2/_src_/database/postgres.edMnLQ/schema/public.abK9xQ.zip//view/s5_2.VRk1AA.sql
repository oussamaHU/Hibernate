create view s5_2(resultaat) as
SELECT 'S5.2 heeft nog geen uitwerking - misschien moet je de DROP VIEW ... regel nog activeren?'::text AS resultaat;

alter table s5_2
    owner to postgres;


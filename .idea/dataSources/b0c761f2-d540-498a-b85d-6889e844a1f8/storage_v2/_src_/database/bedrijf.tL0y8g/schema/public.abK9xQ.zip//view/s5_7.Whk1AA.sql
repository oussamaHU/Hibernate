create view s5_7(voorl, naam) as
SELECT m.voorl,
       m.naam
FROM medewerkers m
WHERE m.functie::text = 'TRAINER'::text
  AND (m.chef IN (SELECT i.cursist
                  FROM inschrijvingen i,
                       cursussen c
                  WHERE c.type = 'ALG'::bpchar
                    AND m.chef = i.cursist
                    AND (i.begindatum IN (SELECT u.begindatum
                                          FROM uitvoeringen u
                                          WHERE m.mnr = u.docent
                                            AND c.code::text = u.cursus::text))));

alter table s5_7
    owner to postgres;


create view s2_5_test(cursus) as
SELECT uitvoeringen.cursus
FROM uitvoeringen
         JOIN medewerkers ON medewerkers.mnr = uitvoeringen.docent
WHERE medewerkers.naam::text = 'SMIT'::text
  AND uitvoeringen.cursus::text = 'S02'::text
  AND date_part('month'::text, uitvoeringen.begindatum) = 3::double precision
  AND date_part('day'::text, uitvoeringen.begindatum) = 2::double precision;

alter table s2_5_test
    owner to postgres;


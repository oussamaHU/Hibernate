create view s2_3_test(cursus, begindatum) as
SELECT answer.cursus,
       answer.begindatum
FROM (VALUES ('OAG'::character varying(4), '2019-08-10'::date),
             ('S02'::character varying, '2019-10-04'::date),
             ('JAV'::character varying, '2019-12-13'::date),
             ('XML'::character varying, '2020-09-18'::date),
             ('RSO'::character varying, '2021-02-24'::date)) answer(cursus, begindatum);

alter table s2_3_test
    owner to postgres;


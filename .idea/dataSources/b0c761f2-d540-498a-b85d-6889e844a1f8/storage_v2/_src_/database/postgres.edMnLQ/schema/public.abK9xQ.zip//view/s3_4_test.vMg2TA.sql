create view s3_4_test(afdeling, hoofd, column3) as
SELECT answer.afdeling,
       answer.hoofd,
       answer.column3
FROM (VALUES ('ALDERS'::character varying(12), 'VERKOOP'::character varying(20), 'UTRECHT'::character varying(20)),
             ('DE WAARD'::character varying, 'VERKOOP'::character varying, 'UTRECHT'::character varying),
             ('JANSEN'::character varying, 'OPLEIDINGEN'::character varying, 'DE MEERN'::character varying),
             ('MARTENS'::character varying, 'VERKOOP'::character varying, 'UTRECHT'::character varying),
             ('BLAAK'::character varying, 'VERKOOP'::character varying, 'UTRECHT'::character varying),
             ('CLERCKX'::character varying, 'HOOFDKANTOOR'::character varying, 'LEIDEN'::character varying),
             ('SCHOTTEN'::character varying, 'OPLEIDINGEN'::character varying, 'DE MEERN'::character varying),
             ('DE KONING'::character varying, 'HOOFDKANTOOR'::character varying, 'LEIDEN'::character varying),
             ('DEN DRAAIER'::character varying, 'VERKOOP'::character varying, 'UTRECHT'::character varying),
             ('ADAMS'::character varying, 'OPLEIDINGEN'::character varying, 'DE MEERN'::character varying),
             ('SPIJKER'::character varying, 'OPLEIDINGEN'::character varying, 'DE MEERN'::character varying),
             ('MOLENAAR'::character varying, 'HOOFDKANTOOR'::character varying, 'LEIDEN'::character varying),
             ('SMIT'::character varying, 'OPLEIDINGEN'::character varying, 'DE MEERN'::character varying),
             ('JANSEN'::character varying, 'VERKOOP'::character varying,
              'UTRECHT'::character varying)) answer(afdeling, hoofd, column3);

alter table s3_4_test
    owner to postgres;


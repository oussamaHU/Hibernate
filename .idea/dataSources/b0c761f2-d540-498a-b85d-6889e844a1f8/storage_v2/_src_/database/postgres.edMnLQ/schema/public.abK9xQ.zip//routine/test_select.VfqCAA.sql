create function test_select(_exercise_nr text) returns text
    language plpgsql
as
$$
DECLARE _sol_name text := REPLACE(LOWER(_exercise_nr), '.', '_');
	DECLARE _test_name text := _sol_name || '_test'; 
	DECLARE _query_res text;
	DECLARE _missing_count int := 0;
	DECLARE _excess_count int := 0;
	DECLARE _missing_query text := 'SELECT * FROM ' || _test_name || ' EXCEPT SELECT * FROM ' || _sol_name;
	DECLARE _excess_query text := 'SELECT * FROM ' || _sol_name || ' EXCEPT SELECT * FROM ' || _test_name;
	DECLARE _rows RECORD;
	BEGIN
		BEGIN
			EXECUTE 'SELECT * FROM ' || _sol_name INTO _query_res;
			IF POSITION('heeft nog geen uitwerking' IN _query_res) <> 0
				THEN RETURN _query_res;
			END IF;
		EXCEPTION
			WHEN OTHERS THEN 
				RAISE notice 'mislukt: %', sqlerrm;
				NULL;
		END;	
		
		FOR _rows IN EXECUTE _missing_query LOOP
			_missing_count := _missing_count + 1;
		END LOOP;

		FOR _rows IN EXECUTE _excess_query LOOP
			_excess_count := _excess_count + 1;
		END LOOP;
		
		IF _missing_count = 0 AND _excess_count = 0 THEN
			RETURN _exercise_nr || ' geeft de juiste resultaten!';
		ELSE
			RETURN _exercise_nr || ' geeft niet de juiste resultaten: er zijn ' || _excess_count::text || ' verkeerde rijen teveel en ' || _missing_count::text || ' goede rijen ontbreken.';
		END IF;
	EXCEPTION
		WHEN SQLSTATE '42804' THEN
			RETURN _exercise_nr || ' is niet correct: de kolomnamen of de kolomtypen kloppen niet.';
		WHEN SQLSTATE '42601' THEN
			RETURN _exercise_nr || ' is niet correct: het aantal kolommen klopt niet.';
	END;
$$;

alter function test_select(text) owner to postgres;


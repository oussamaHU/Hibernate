create view s4_7_test(aantal_medewerkers, commissie_medewerkers, commissie_verkopers) as
SELECT answer.aantal_medewerkers,
       answer.commissie_medewerkers,
       answer.commissie_verkopers
FROM (VALUES (14::bigint, 150::numeric, 525::numeric)) answer(aantal_medewerkers, commissie_medewerkers, commissie_verkopers);

alter table s4_7_test
    owner to postgres;


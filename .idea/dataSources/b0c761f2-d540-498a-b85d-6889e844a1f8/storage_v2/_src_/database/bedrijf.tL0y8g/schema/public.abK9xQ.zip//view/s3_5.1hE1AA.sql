create view s3_5(cursist) as
SELECT m.naam AS cursist
FROM inschrijvingen i
         JOIN medewerkers m ON m.mnr = i.cursist
WHERE i.begindatum = '2019-04-12'::date;

alter table s3_5
    owner to postgres;


create view s5_1_test(cursist) as
SELECT answer.cursist
FROM (VALUES (7499::numeric(4, 0))) answer(cursist);

alter table s5_1_test
    owner to postgres;


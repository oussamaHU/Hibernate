create view s1_4_test(column_name) as
SELECT columns.column_name
FROM information_schema.columns
WHERE columns.table_schema::text = 'public'::text
  AND columns.table_name::text = 'adressen'::text
  AND (columns.column_name::text = ANY
       (ARRAY ['postcode'::character varying, 'huisnummer'::character varying, 'ingangsdatum'::character varying, 'einddatum'::character varying, 'telefoon'::character varying, 'med_mnr'::character varying]::text[]));

alter table s1_4_test
    owner to postgres;

